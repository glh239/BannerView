//
//  ViewController.h
//  GLHBannerView
//
//  Created by glh on 17/1/11.
//  Copyright © 2017年 glh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

